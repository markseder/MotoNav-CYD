#pragma once

constexpr int GNSS_UART_NUMBER = 2;
constexpr int GNSS_RX_PIN = 35;
constexpr int GNSS_TX_PIN = -1;
constexpr uint32_t GNSS_BAUD = 9600;

constexpr int TOUCH_CS_PIN = 33;
constexpr int TOUCH_IRQ_PIN = 36;
constexpr int TOUCH_MOSI_PIN = 32;
constexpr int TOUCH_MISO_PIN = 39;
constexpr int TOUCH_CLK_PIN = 25;

constexpr int SD_CS_PIN = 5;
constexpr int SD_SCK_PIN = 18;
constexpr int SD_MISO_PIN = 19;
constexpr int SD_MOSI_PIN = 23;

constexpr uint32_t GNSS_DATA_TIMEOUT_MS = 3000;
constexpr uint32_t SCREEN_REFRESH_MS = 200;
constexpr uint32_t TOUCH_MIN_PRESS_MS = 60;
constexpr uint32_t MENU_HOLD_MS = 1500;

constexpr double SPEED_NOISE_FLOOR_KMH = 0.8;
constexpr double MOVING_SPEED_THRESHOLD_KMH = 2.0;
constexpr double MAX_VALID_SPEED_KMH = 220.0;
constexpr double MAX_HDOP_FOR_DISTANCE = 4.0;
constexpr double MAX_HDOP_FOR_TRACK = 5.0;
constexpr uint32_t MIN_SATELLITES_FOR_TRACK = 4;
constexpr double MIN_TRACK_POINT_DISTANCE_M = 1.5;
constexpr double MAX_TRACK_SEGMENT_DISTANCE_M = 100.0;
constexpr uint32_t MAX_TRACK_POINT_GAP_MS = 5000;
constexpr double MAX_SEGMENT_DISTANCE_M = 80.0;
constexpr uint32_t MAX_POSITION_GAP_MS = 5000;
constexpr uint32_t MAX_MOTION_SAMPLE_MS = 1000;

constexpr double SPEED_SCREEN_ENTER_KMH = 5.0;
constexpr double SPEED_SCREEN_EXIT_KMH = 1.0;
constexpr uint32_t SPEED_SCREEN_ENTER_HOLD_MS = 800;
constexpr uint32_t SPEED_SCREEN_EXIT_HOLD_MS = 3000;

constexpr double MENU_MAX_SPEED_KMH = 2.0;
constexpr double TRACK_MOVING_THRESHOLD_KMH = 2.0;
constexpr uint32_t TRACK_POINT_INTERVAL_MS = 1000;
constexpr uint32_t TRACK_AUTO_PAUSE_MS = 10000;
constexpr uint32_t TRACK_FLUSH_INTERVAL_MS = 2000;
constexpr uint32_t TRACK_RECOVERED_NOTICE_MS = 5000;


constexpr double MAX_SPEED_JUMP_KMH_PER_S = 45.0;
constexpr double SPEED_FILTER_ALPHA_LOW = 0.22;
constexpr double SPEED_FILTER_ALPHA_NORMAL = 0.38;
